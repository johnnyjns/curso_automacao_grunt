(function() {
  var nome;

  nome = "Flávio";

}).call(this);
